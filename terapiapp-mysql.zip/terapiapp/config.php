<?php
// ================================================
// config.php - Conexión a MySQL y funciones comunes
// ================================================

date_default_timezone_set('America/Bogota');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------- Datos de conexión (XAMPP por defecto) ----------
$DB_HOST    = 'localhost';
$DB_NOMBRE  = 'terapiapp';
$DB_USUARIO = 'root';
$DB_CLAVE   = '';          // En XAMPP por defecto está vacía

// Horario de atención: una cita por hora, lunes a sábado
const HORA_INICIO = 7;   // 7:00 a.m.
const HORA_FIN    = 18;  // última cita 6:00 p.m.

if (is_file(__DIR__ . '/config.local.php')) {
    require __DIR__ . '/config.local.php';   // opcional, para otra configuración
}

if (!isset($db)) {
    $db = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NOMBRE;charset=utf8mb4",
        $DB_USUARIO,
        $DB_CLAVE,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
}

// Ejecutar una consulta preparada
function q($sql, $params = []) {
    global $db;
    $st = $db->prepare($sql);
    $st->execute($params);
    return $st;
}

function ahora() { return date('Y-m-d H:i:s'); }
function hoy()   { return date('Y-m-d'); }

function usuario_actual() {
    return $_SESSION['usuario'] ?? null;
}

// Guardar lo que pasa en la página (lo ve el administrador)
function registrar($accion, $detalle = '') {
    $u = usuario_actual();
    q("INSERT INTO actividad (id_usuario, accion, detalle, creado_en) VALUES (?, ?, ?, ?)",
      [$u['id'] ?? null, $accion, mb_substr($detalle, 0, 255), ahora()]);
}

// Enlace de videollamada gratuito para citas virtuales (Jitsi Meet)
function crear_enlace_virtual() {
    return 'https://meet.jit.si/TerapiApp-' . bin2hex(random_bytes(6));
}
