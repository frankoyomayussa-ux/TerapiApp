-- =====================================================
-- TerapiApp - Base de datos completa
-- Ejecútalo en phpMyAdmin (pestaña "SQL").
-- OJO: borra y vuelve a crear las tablas de terapiapp.
-- =====================================================

CREATE DATABASE IF NOT EXISTS terapiapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE terapiapp;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS actividad;
DROP TABLE IF EXISTS notas;
DROP TABLE IF EXISTS citas;
DROP TABLE IF EXISTS pacientes;
DROP TABLE IF EXISTS terapeutas;
DROP TABLE IF EXISTS especialidades;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS = 1;

-- Cuentas de acceso (administrador, terapeutas y pacientes)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,                -- password_hash()
    rol ENUM('admin','terapeuta','paciente') NOT NULL DEFAULT 'paciente',
    activo TINYINT(1) NOT NULL DEFAULT 1,
    ultimo_acceso DATETIME NULL,
    creado_en DATETIME NOT NULL
) ENGINE=InnoDB;

-- Tipos de psicología / servicios
CREATE TABLE especialidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    icono VARCHAR(10) NOT NULL,
    descripcion TEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE terapeutas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NULL UNIQUE,
    id_especialidad INT NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    enfoque VARCHAR(200) NOT NULL,
    descripcion TEXT NOT NULL,
    anos_experiencia INT NOT NULL DEFAULT 1,
    modalidad ENUM('Ambas','Virtual','Presencial') NOT NULL DEFAULT 'Ambas',
    sede VARCHAR(150) NOT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (id_especialidad) REFERENCES especialidades(id)
) ENGINE=InnoDB;

-- Datos personales del paciente (se llenan al agendar)
CREATE TABLE pacientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL UNIQUE,
    documento VARCHAR(30) NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    telefono VARCHAR(30) NOT NULL,
    correo VARCHAR(150),
    ciudad VARCHAR(100),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE citas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_terapeuta INT NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    modalidad ENUM('Virtual','Presencial') NOT NULL,
    motivo VARCHAR(255),
    estado ENUM('Pendiente','Confirmada','Cancelada','Atendida') NOT NULL DEFAULT 'Pendiente',
    enlace_virtual VARCHAR(255),
    creado_en DATETIME NOT NULL,
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id) ON DELETE CASCADE,
    FOREIGN KEY (id_terapeuta) REFERENCES terapeutas(id) ON DELETE CASCADE,
    INDEX idx_agenda (id_terapeuta, fecha, hora)
) ENGINE=InnoDB;

-- Notas de sesión que escribe el terapeuta (solo las ve él)
CREATE TABLE notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_terapeuta INT NOT NULL,
    nota TEXT NOT NULL,
    creado_en DATETIME NOT NULL,
    FOREIGN KEY (id_paciente) REFERENCES pacientes(id) ON DELETE CASCADE,
    FOREIGN KEY (id_terapeuta) REFERENCES terapeutas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Registro de lo que pasa en la página (lo revisa el administrador)
CREATE TABLE actividad (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NULL,
    accion VARCHAR(60) NOT NULL,
    detalle VARCHAR(255),
    creado_en DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------
-- DATOS INICIALES
-- ---------------------------------------------------

INSERT INTO especialidades (id, nombre, icono, descripcion) VALUES
(1, 'Psicología Clínica', '🧠', 'Evaluación y tratamiento de ansiedad, depresión, estrés, duelo y otras dificultades emocionales en adultos.'),
(2, 'Psicología Infantil y del Adolescente', '🧸', 'Acompañamiento a niños, niñas y jóvenes en temas de conducta, emociones, aprendizaje y crianza.'),
(3, 'Terapia de Pareja y Familia', '👨‍👩‍👧', 'Mejora de la comunicación, manejo de conflictos, separaciones y dinámicas familiares.'),
(4, 'Neuropsicología', '🔬', 'Evaluación y rehabilitación de memoria, atención y otras funciones cognitivas.'),
(5, 'Psicología Educativa', '📚', 'Orientación vocacional, dificultades de aprendizaje y apoyo a estudiantes y docentes.'),
(6, 'Psicología Organizacional', '💼', 'Bienestar laboral, manejo del estrés en el trabajo, liderazgo y orientación de carrera.'),
(7, 'Psicología de la Salud', '❤️', 'Apoyo emocional a personas con enfermedades crónicas, dolor o procesos médicos largos.'),
(8, 'Psicología Deportiva', '🏃', 'Rendimiento, concentración, manejo de la presión y motivación en deportistas.');

-- Administrador   -> admin@terapiapp.com / admin123
-- Terapeutas      -> <correo de cada uno> / terapeuta123
-- Pacientes       -> juan.perez@correo.com / paciente123 (y los demás)
-- (Cambia estas contraseñas después de probar)
INSERT INTO usuarios (id, nombre, correo, contrasena, rol, creado_en) VALUES
(1, 'Administrador', 'admin@terapiapp.com', '$2y$12$SSfKm0B4xYYZuR0sWirHuOlkFLzmnz/9/GMv8hxghxFKbrgGXTd6K', 'admin', NOW()),
(2, 'Laura Gómez', 'laura.gomez@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(3, 'Andrés Martínez', 'andres.martinez@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(4, 'Camila Rojas', 'camila.rojas@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(5, 'Julián Torres', 'julian.torres@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(6, 'Valentina Herrera', 'valentina.herrera@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(7, 'Santiago Castro', 'santiago.castro@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(8, 'Daniela Moreno', 'daniela.moreno@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(9, 'Felipe Ramírez', 'felipe.ramirez@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(10, 'Mariana Ortiz', 'mariana.ortiz@terapiapp.com', '$2y$12$0mGR532VYSS9QfKt1Dtbb.dl5ZPbg.q7Th9RLtrfPCk4D4KJ5tM72', 'terapeuta', NOW()),
(11, 'Juan Pérez', 'juan.perez@correo.com', '$2y$12$RDmpHv/JFscPFmJZRsr78eFi4FZ5X2Kdm81/Tbd12rnKk4Zbc670W', 'paciente', NOW()),
(12, 'María Rodríguez', 'maria.rodriguez@correo.com', '$2y$12$RDmpHv/JFscPFmJZRsr78eFi4FZ5X2Kdm81/Tbd12rnKk4Zbc670W', 'paciente', NOW()),
(13, 'Carlos Sánchez', 'carlos.sanchez@correo.com', '$2y$12$RDmpHv/JFscPFmJZRsr78eFi4FZ5X2Kdm81/Tbd12rnKk4Zbc670W', 'paciente', NOW()),
(14, 'Ana Torres', 'ana.torres@correo.com', '$2y$12$RDmpHv/JFscPFmJZRsr78eFi4FZ5X2Kdm81/Tbd12rnKk4Zbc670W', 'paciente', NOW());

INSERT INTO terapeutas (id_usuario, id_especialidad, nombre, titulo, enfoque, descripcion, anos_experiencia, modalidad, sede) VALUES
(2, 1, 'Laura Gómez', 'Psicóloga clínica, Mg. en Psicología Clínica', 'Terapia cognitivo-conductual', 'Acompaña a adultos con ansiedad, depresión y estrés. Trabaja con herramientas prácticas para el día a día.', 12, 'Ambas', 'Sede Chapinero'),
(3, 2, 'Andrés Martínez', 'Psicólogo, Esp. en Psicología Infantil', 'Terapia de juego y orientación a padres', 'Trabaja con niños y adolescentes en manejo de emociones, conducta y adaptación escolar.', 9, 'Presencial', 'Sede Usaquén'),
(4, 3, 'Camila Rojas', 'Psicóloga, Mg. en Terapia Familiar', 'Terapia sistémica', 'Acompaña a parejas y familias en procesos de comunicación, conflictos y cambios importantes.', 10, 'Ambas', 'Sede Chapinero'),
(5, 4, 'Julián Torres', 'Neuropsicólogo', 'Evaluación y rehabilitación cognitiva', 'Realiza evaluaciones de memoria y atención, y planes de rehabilitación después de lesiones.', 15, 'Presencial', 'Sede Salitre'),
(6, 1, 'Valentina Herrera', 'Psicóloga clínica', 'Terapia de aceptación y compromiso (ACT)', 'Especialista en duelo, autoestima y procesos de cambio personal en jóvenes y adultos.', 7, 'Virtual', 'Atención 100% virtual'),
(7, 6, 'Santiago Castro', 'Psicólogo organizacional', 'Coaching y bienestar laboral', 'Acompaña a trabajadores con estrés laboral, agotamiento y decisiones de carrera.', 8, 'Ambas', 'Sede Salitre'),
(8, 5, 'Daniela Moreno', 'Psicóloga educativa', 'Orientación vocacional y aprendizaje', 'Apoya a estudiantes con dificultades de aprendizaje y en la elección de su carrera.', 6, 'Ambas', 'Sede Usaquén'),
(9, 7, 'Felipe Ramírez', 'Psicólogo de la salud', 'Manejo del dolor y adherencia a tratamientos', 'Acompaña a pacientes con enfermedades crónicas y a sus familias.', 11, 'Virtual', 'Atención 100% virtual'),
(10, 8, 'Mariana Ortiz', 'Psicóloga deportiva', 'Entrenamiento mental y manejo de la ansiedad competitiva', 'Trabaja con deportistas y equipos en concentración, confianza y manejo de la presión.', 5, 'Ambas', 'Sede Salitre');

INSERT INTO pacientes (id, id_usuario, documento, nombre, fecha_nacimiento, telefono, correo, ciudad) VALUES
(1, 11, '1012345678', 'Juan Pérez', '1990-03-14', '3001234567', 'juan.perez@correo.com', 'Bogotá'),
(2, 12, '52123456', 'María Rodríguez', '1985-11-02', '3109876543', 'maria.rodriguez@correo.com', 'Bogotá'),
(3, 13, '80123456', 'Carlos Sánchez', '2001-07-21', '3154567890', 'carlos.sanchez@correo.com', 'Bogotá'),
(4, 14, '1098765432', 'Ana Torres', '1995-01-30', '3207654321', 'ana.torres@correo.com', 'Bogotá');

-- Citas de ejemplo alrededor de la semana actual
-- (@lunes = lunes de esta semana; si hoy es domingo, el de la semana que viene)
SET @lunes := DATE_ADD(CURDATE(), INTERVAL IF(WEEKDAY(CURDATE()) = 6, 1, -WEEKDAY(CURDATE())) DAY);

INSERT INTO citas (id_paciente, id_terapeuta, fecha, hora, modalidad, motivo, estado, enlace_virtual, creado_en) VALUES
(1, 1, DATE_ADD(@lunes, INTERVAL -14 DAY), '09:00:00', 'Virtual', 'Ansiedad en el trabajo', 'Atendida', 'https://meet.jit.si/TerapiApp-demo01', DATE_ADD(@lunes, INTERVAL -17 DAY)),
(1, 1, DATE_ADD(@lunes, INTERVAL -7 DAY), '09:00:00', 'Virtual', 'Seguimiento', 'Atendida', 'https://meet.jit.si/TerapiApp-demo02', DATE_ADD(@lunes, INTERVAL -10 DAY)),
(2, 3, DATE_ADD(@lunes, INTERVAL -12 DAY), '15:00:00', 'Presencial', 'Terapia de pareja', 'Atendida', NULL, DATE_ADD(@lunes, INTERVAL -15 DAY)),
(3, 7, DATE_ADD(@lunes, INTERVAL -9 DAY), '11:00:00', 'Presencial', 'Orientación vocacional', 'Cancelada', NULL, DATE_ADD(@lunes, INTERVAL -12 DAY)),
(4, 5, DATE_ADD(@lunes, INTERVAL -5 DAY), '16:00:00', 'Virtual', 'Duelo', 'Atendida', 'https://meet.jit.si/TerapiApp-demo03', DATE_ADD(@lunes, INTERVAL -8 DAY)),
(1, 1, @lunes, '09:00:00', 'Virtual', 'Seguimiento', 'Confirmada', 'https://meet.jit.si/TerapiApp-demo04', DATE_ADD(@lunes, INTERVAL -3 DAY)),
(2, 3, DATE_ADD(@lunes, INTERVAL 1 DAY), '15:00:00', 'Presencial', 'Terapia de pareja', 'Confirmada', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY)),
(3, 7, DATE_ADD(@lunes, INTERVAL 2 DAY), '10:00:00', 'Virtual', 'Orientación vocacional', 'Pendiente', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY)),
(4, 5, DATE_ADD(@lunes, INTERVAL 3 DAY), '16:00:00', 'Virtual', 'Duelo', 'Pendiente', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY)),
(2, 1, DATE_ADD(@lunes, INTERVAL 4 DAY), '11:00:00', 'Presencial', 'Estrés', 'Pendiente', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY)),
(3, 6, DATE_ADD(@lunes, INTERVAL 7 DAY), '08:00:00', 'Virtual', 'Estrés laboral', 'Pendiente', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY)),
(4, 9, DATE_ADD(@lunes, INTERVAL 8 DAY), '17:00:00', 'Presencial', 'Ansiedad antes de competir', 'Confirmada', NULL, DATE_ADD(@lunes, INTERVAL -3 DAY));

INSERT INTO notas (id_paciente, id_terapeuta, nota, creado_en) VALUES
(1, 1, 'Primera sesión. Refiere ansiedad por carga laboral. Se trabajó respiración diafragmática. Tarea: registro de pensamientos.', DATE_ADD(@lunes, INTERVAL -14 DAY)),
(1, 1, 'Trajo el registro. Identifica pensamientos catastróficos. Se practicó reestructuración cognitiva.', DATE_ADD(@lunes, INTERVAL -7 DAY));

INSERT INTO actividad (id_usuario, accion, detalle, creado_en) VALUES
(1, 'Datos iniciales', 'Se cargaron los datos de demostración', NOW());
